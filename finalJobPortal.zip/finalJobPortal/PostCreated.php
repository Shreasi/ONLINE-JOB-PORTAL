<html>
<head>

<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="icon" href="img/favicon.svg" type="image/x-icon">
<title> Create A Post | Employer</title>

<link href="css/simpleGridTemplate.css" rel="stylesheet" type="text/css">
<link href="css/bootstrap.css" rel="stylesheet" type="text/css">
<link href="css/Animate.css" rel="stylesheet" type="text/css">

<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
 <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<link href="css/Animate.css" rel="stylesheet" type="text/css">
<link href="css/animate.min.css" rel="stylesheet" type="text/css">

<!--FONTS-->
<link href="https://fonts.googleapis.com/css2?family=Sora:wght@200&display=swap" rel="stylesheet">
<style>
    
    
    
    
    
    
</style>


<?php

include 'navBar.php';

?>


<div style="background-color: #FF5757; width: 100%; height: 650px; padding-top: 200px; text-align: center;">
    <h1 style="font-size: 80px;">Your Post Published!!</h1>
    <img src="img/5.gif" width="300" height="300"/>

</div>


<?php

include 'footer.php';

?>
